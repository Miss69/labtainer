# dc_bruteforce.py
#!/usr/bin/env python3

import cv2
import numpy as np
import random
import argparse

MAGIC_HEADER = "STEGO:"
MAX_SEED = 10000


def extract_candidate_bits(video_path, seed, num_bits=512):

    cap = cv2.VideoCapture(video_path)

    if not cap.isOpened():
        print("[!] Cannot open video")
        return None

    random.seed(seed)

    bits = []

    frame_positions = []

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    for _ in range(num_bits):

        frame_id = random.randint(0, total_frames - 1)
        frame_positions.append(frame_id)

    for frame_id in frame_positions:

        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_id)

        ret, frame = cap.read()

        if not ret:
            continue

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        block = gray[0:8, 0:8]

        dct_block = cv2.dct(np.float32(block))

        dc = int(dct_block[0, 0])

        # Giả sử bit được nhúng bằng parity
        bit = dc & 1

        bits.append(str(bit))

    cap.release()

    return ''.join(bits)


def bits_to_text(bits):

    chars = []

    for i in range(0, len(bits), 8):

        byte = bits[i:i+8]

        if len(byte) < 8:
            break

        chars.append(chr(int(byte, 2)))

    return ''.join(chars)


def brute_force(video_path):

    print("[*] Starting brute-force attack...")
    print(f"[*] Max seed: {MAX_SEED}")

    for seed in range(MAX_SEED):

        bits = extract_candidate_bits(video_path, seed)

        if bits is None:
            continue

        text = bits_to_text(bits)

        if MAGIC_HEADER in text:

            print(f"\n[+] Possible seed found: {seed}")

            print("[+] Extracted message preview:")
            print(text[:200])

            return

        if seed % 500 == 0:
            print(f"[-] Tested seed: {seed}")

    print("[!] No valid seed found")


def main():

    parser = argparse.ArgumentParser(
        description="DC Steganography Seed Brute-force"
    )

    parser.add_argument(
        'video',
        help='Input suspect video'
    )

    parser.add_argument(
        '--mode',
        required=True,
        choices=['extract'],
        help='Operation mode'
    )

    args = parser.parse_args()

    if args.mode == 'extract':
        brute_force(args.video)


if __name__ == "__main__":
    main()
