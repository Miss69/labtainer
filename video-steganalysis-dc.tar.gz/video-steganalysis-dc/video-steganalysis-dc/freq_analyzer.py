# freq_analyzer.py
#!/usr/bin/env python3

import cv2
import numpy as np
import matplotlib.pyplot as plt
import argparse
import os

def extract_dc_values(video_path, sample_step=30):
    cap = cv2.VideoCapture(video_path)

    if not cap.isOpened():
        print(f"[!] Cannot open video: {video_path}")
        return []

    dc_values = []
    frame_index = 0

    while True:
        ret, frame = cap.read()

        if not ret:
            break

        # Chỉ lấy mỗi sample_step frame để giảm thời gian xử lý
        if frame_index % sample_step == 0:

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            h, w = gray.shape

            # Chia block 8x8 giống MPEG/JPEG
            for y in range(0, h - 7, 8):
                for x in range(0, w - 7, 8):

                    block = gray[y:y+8, x:x+8]

                    # DCT
                    dct_block = cv2.dct(np.float32(block))

                    # Hệ số DC
                    dc = int(dct_block[0, 0])

                    dc_values.append(dc)

        frame_index += 1

    cap.release()
    return dc_values


def plot_histogram(dc_values, title):
    plt.figure(figsize=(10, 5))

    plt.hist(
        dc_values,
        bins=80,
        color='blue',
        alpha=0.75
    )

    plt.title(f"DC Histogram - {title}")
    plt.xlabel("DC Coefficient")
    plt.ylabel("Frequency")

    plt.grid(True)
    plt.tight_layout()
    plt.show()


def main():
    parser = argparse.ArgumentParser(
        description="Analyze DC coefficient histogram from video"
    )

    parser.add_argument(
        'videos',
        nargs='+',
        help='Input video files'
    )

    args = parser.parse_args()

    for video in args.videos:

        print(f"\n[*] Processing: {video}")

        dc_values = extract_dc_values(video)

        if len(dc_values) == 0:
            print("[!] No DC values extracted.")
            continue

        print(f"[+] Extracted {len(dc_values)} DC coefficients")

        plot_histogram(
            dc_values,
            os.path.basename(video)
        )


if __name__ == "__main__":
    main()
