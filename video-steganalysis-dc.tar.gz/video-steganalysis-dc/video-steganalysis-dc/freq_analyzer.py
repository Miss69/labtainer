# freq_analyzer.py
#!/usr/bin/env python3

import cv2
import numpy as np
import argparse
import os

def extract_dc_values(video_path, sample_step=30):
    cap = cv2.VideoCapture(video_path)

    if not cap.isOpened():
        print(f"[!] Cannot open video: {video_path}")
        return []

    dc_values = []
    frame_index = 0

    while True:
        ret, frame = cap.read()

        if not ret:
            break

        # Chỉ lấy mỗi sample_step frame để giảm thời gian xử lý
        if frame_index % sample_step == 0:

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            h, w = gray.shape

            # Chia block 8x8 giống MPEG/JPEG
            for y in range(0, h - 7, 8):
                for x in range(0, w - 7, 8):

                    block = gray[y:y+8, x:x+8]

                    # DCT
                    dct_block = cv2.dct(np.float32(block))

                    # Hệ số DC
                    dc = int(dct_block[0, 0])

                    dc_values.append(dc)

        frame_index += 1

    cap.release()
    return dc_values


def plot_histogram(dc_values, title):

    mean_dc = np.mean(dc_values)
    std_dc = np.std(dc_values)

    even_count = sum(1 for x in dc_values if x % 2 == 0)
    odd_count = sum(1 for x in dc_values if x % 2 != 0)

    total = len(dc_values)

    print(f"\n===== Analysis: {title} =====")

    print(f"Mean DC          : {mean_dc:.2f}")
    print(f"Std Deviation    : {std_dc:.2f}")

    print(f"Even DC count    : {even_count}")
    print(f"Odd DC count     : {odd_count}")

    print(f"Even Ratio       : {even_count/total:.4f}")
    print(f"Odd Ratio        : {odd_count/total:.4f}")

    parity_diff = abs(even_count - odd_count)

    print(f"Parity Difference: {parity_diff}")
    
    suspicious_score = 0

    # parity quá lệch
    if even_count / total > 0.80 or even_count / total < 0.20:
        suspicious_score += 1

    # variance thấp bất thường
    if std_dc < 180:
        suspicious_score += 1

    # mean DC quá khác biệt
    if mean_dc > 1000:
        suspicious_score += 1

    print(f"Suspicious Score : {suspicious_score}")

    if suspicious_score >= 2:
        print("[!] Possible steganography detected")
    else:
        print("[+] Distribution appears normal")


def main():
    parser = argparse.ArgumentParser(
        description="Analyze DC coefficient histogram from video"
    )

    parser.add_argument(
        'videos',
        nargs='+',
        help='Input video files'
    )

    args = parser.parse_args()

    for video in args.videos:

        print(f"\n[*] Processing: {video}")

        dc_values = extract_dc_values(video)

        if len(dc_values) == 0:
            print("[!] No DC values extracted.")
            continue

        print(f"[+] Extracted {len(dc_values)} DC coefficients")
        
        mean_dc = np.mean(dc_values)
        std_dc = np.std(dc_values)

        even_count = sum(1 for x in dc_values if x % 2 == 0)
        odd_count = sum(1 for x in dc_values if x % 2 != 0)

        total = len(dc_values)

        print(f"Mean DC          : {mean_dc:.2f}")
        print(f"Std Deviation    : {std_dc:.2f}")

        print(f"Even DC count    : {even_count}")
        print(f"Odd DC count     : {odd_count}")

        print(f"Even Ratio       : {even_count/total:.4f}")
        print(f"Odd Ratio        : {odd_count/total:.4f}")

        plot_histogram(
            dc_values,
            os.path.basename(video)
        )


if __name__ == "__main__":
    main()
