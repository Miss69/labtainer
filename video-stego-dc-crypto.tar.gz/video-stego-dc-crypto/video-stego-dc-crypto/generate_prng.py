
#!/usr/bin/env python3

import argparse
import random

def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--length", type=int, required=True)
    parser.add_argument("--out", required=True)

    args = parser.parse_args()

    random.seed(args.seed)

    values = [-1, 0, 1]

    with open(args.out, "wb") as f:
        for _ in range(args.length):
            val = random.choice(values)

            # lưu dưới dạng byte:
            # -1 -> 0
            # 0  -> 1
            # 1  -> 2
            f.write(int(val + 1).to_bytes(1, "little"))

    print(f"[+] PRNG noise generated")
    print(f"[+] Seed: {args.seed}")
    print(f"[+] Length: {args.length}")
    print(f"[+] Output: {args.out}")

if __name__ == "__main__":
    main()
