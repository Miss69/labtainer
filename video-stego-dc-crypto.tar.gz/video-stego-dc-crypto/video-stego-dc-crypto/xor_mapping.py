
#!/usr/bin/env python3

import argparse

def map_bit(bit):
    return -1 if bit == 0 else 1

def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("secret_file")
    parser.add_argument("noise_file")
    parser.add_argument("--out", required=True)

    args = parser.parse_args()

    with open(args.secret_file, "rb") as f:
        secret = f.read()

    with open(args.noise_file, "rb") as f:
        noise = f.read()

    bits = []

    # chuyển text -> bit
    for byte in secret:
        for i in range(8):
            bits.append((byte >> (7 - i)) & 1)

    # ánh xạ 0 -> -1 ; 1 -> 1
    mapped = [map_bit(b) for b in bits]

    payload = bytearray()

    for i in range(min(len(mapped), len(noise))):
        n = noise[i] - 1

        # XOR đơn giản hóa
        x = mapped[i] ^ (n & 0x01)

        payload.append(x & 0xFF)

    with open(args.out, "wb") as f:
        f.write(payload)

    print(f"[+] Payload encoded")
    print(f"[+] Output: {args.out}")

if __name__ == "__main__":
    main()

