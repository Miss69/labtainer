#!/usr/bin/env python3

import argparse
import shutil
import os

def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("input_video")
    parser.add_argument("--frame_index", type=int, required=True)
    parser.add_argument("--out", required=True)

    args = parser.parse_args()

    if not os.path.exists(args.input_video):
        print("Input video not found")
        return

    # Giả lập trích xuất I-frame
    shutil.copy(args.input_video, args.out)

    print(f"[+] Extracted I-frame #{args.frame_index}")
    print(f"[+] Output: {args.out}")

if __name__ == "__main__":
    main()
