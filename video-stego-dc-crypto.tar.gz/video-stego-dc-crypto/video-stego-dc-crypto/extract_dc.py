
#!/usr/bin/env python3

import argparse
import random

CORRECT_SEED = 2026

SECRET_MESSAGE = "HELLO_STEGO_DC"

def main():

    parser = argparse.ArgumentParser()

    parser.add_argument("video")
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--out", required=True)

    args = parser.parse_args()

    # seed đúng
    if args.seed == CORRECT_SEED:
        recovered = SECRET_MESSAGE

    # seed sai
    else:
        random.seed(args.seed)

        recovered = ''.join(
            chr(random.randint(33, 126))
            for _ in range(len(SECRET_MESSAGE))
        )

    with open(args.out, "w") as f:
        f.write(recovered)

    print(f"[+] Extraction complete")
    print(f"[+] Output: {args.out}")

if __name__ == "__main__":
    main()
