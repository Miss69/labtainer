#!/usr/bin/env python3

import argparse
import shutil
import random
from PIL import Image, ImageDraw

def create_visual(name, structured=False):

    img = Image.new("RGB", (512, 512), "gray")
    draw = ImageDraw.Draw(img)

    block = 8

    for y in range(0, 512, block):
        for x in range(0, 512, block):

            if structured:
                # tạo vệt có quy luật
                color = 220 if (x // block) % 2 == 0 else 50
            else:
                # tạo nhiễu ngẫu nhiên
                color = random.randint(80, 180)

            draw.rectangle(
                [x, y, x + block, y + block],
                fill=(color, color, color)
            )

    img.save(name)

def main():

    parser = argparse.ArgumentParser()

    parser.add_argument("iframe")
    parser.add_argument("payload")
    parser.add_argument("-k", type=int, required=True)
    parser.add_argument("--out", required=True)

    args = parser.parse_args()

    # giả lập nhúng DC
    shutil.copy(args.iframe, args.out)

    if "bad" in args.out:
        create_visual("bad_embed.jpg", structured=True)
    else:
        create_visual("good_embed.jpg", structured=False)

    print(f"[+] DC embedding simulated")
    print(f"[+] k = {args.k}")
    print(f"[+] Output: {args.out}")

if __name__ == "__main__":
    main()
