# compress_attack.py
#!/usr/bin/env python3

import cv2
import argparse


def recompress(input_video):

    output_video = input_video.replace(".mp4", "_attacked.mp4")

    cap = cv2.VideoCapture(input_video)

    fps = cap.get(cv2.CAP_PROP_FPS)

    if fps <= 0:
        fps = 30

    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    fourcc = cv2.VideoWriter_fourcc(*'mp4v')

    out = cv2.VideoWriter(
        output_video,
        fourcc,
        fps,
        (width, height)
    )

    while True:

        ret, frame = cap.read()

        if not ret:
            break

        out.write(frame)

    cap.release()
    out.release()

    print(f"[+] Simulated compression attack: {output_video}")


def main():

    parser = argparse.ArgumentParser()

    parser.add_argument("videos", nargs='+')

    args = parser.parse_args()

    for video in args.videos:
        recompress(video)


if __name__ == "__main__":
    main()
