# inspect_dc_block.py
#!/usr/bin/env python3

import cv2
import numpy as np
import argparse


def get_dc(frame, block_id):

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    h, w = gray.shape

    blocks_per_row = w // 8

    y = (block_id // blocks_per_row) * 8
    x = (block_id % blocks_per_row) * 8

    block = gray[y:y+8, x:x+8]

    dct_block = cv2.dct(np.float32(block))

    dc = int(dct_block[0, 0])

    return dc


def main():

    parser = argparse.ArgumentParser()

    parser.add_argument("original")
    parser.add_argument("modified")

    parser.add_argument("--block_id", type=int, required=True)

    args = parser.parse_args()

    cap1 = cv2.VideoCapture(args.original)
    cap2 = cv2.VideoCapture(args.modified)

    ret1, frame1 = cap1.read()
    ret2, frame2 = cap2.read()

    if not ret1 or not ret2:
        print("[!] Cannot read frames")
        return

    dc_original = get_dc(frame1, args.block_id)
    dc_modified = get_dc(frame2, args.block_id)

    print("\n=== DC Block Analysis ===")
    print(f"Block ID        : {args.block_id}")
    print(f"Original DC     : {dc_original}")
    print(f"Modified DC     : {dc_modified}")


    cap1.release()
    cap2.release()


if __name__ == "__main__":
    main()
