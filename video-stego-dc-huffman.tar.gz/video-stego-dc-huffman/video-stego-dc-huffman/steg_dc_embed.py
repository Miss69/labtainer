# steg_dc_embed.py
#!/usr/bin/env python3

import cv2
import numpy as np
import argparse

END_MARKER = "###"


def text_to_bits(text):
    return ''.join(format(ord(c), '08b') for c in text)


def embed_message(frame, bits, k):

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    modified = gray.astype(np.float32)

    h, w = gray.shape

    bit_index = 0

    for y in range(0, h - 7, 8):
        for x in range(0, w - 7, 8):

            if bit_index >= len(bits):
                break

            block = modified[y:y+8, x:x+8]

            dct_block = cv2.dct(block)

            bit = int(bits[bit_index])

            delta = (k * 8) if bit == 1 else -(k * 8)

            dct_block[0, 0] += delta

            reconstructed = cv2.idct(dct_block)

            modified[y:y+8, x:x+8] = reconstructed

            bit_index += 1

    modified = np.clip(modified, 0, 255).astype(np.uint8)

    output = np.stack([modified]*3, axis=-1)

    return output


def main():

    parser = argparse.ArgumentParser()

    parser.add_argument("input")
    parser.add_argument("message")

    parser.add_argument("-k", type=int, required=True)
    parser.add_argument("-o", required=True)

    args = parser.parse_args()

    cap = cv2.VideoCapture(args.input)

    fps = cap.get(cv2.CAP_PROP_FPS)

    if fps <= 0:
        fps = 30

    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    fourcc = cv2.VideoWriter_fourcc(*'mp4v')

    out = cv2.VideoWriter(
        args.o,
        fourcc,
        fps,
        (width, height)
    )

    bits = text_to_bits(args.message + END_MARKER)

    embedded = False

    while True:

        ret, frame = cap.read()

        if not ret:
            break

        if not embedded:
            frame = embed_message(frame, bits, args.k)
            embedded = True

        out.write(frame)

    cap.release()
    out.release()

    print(f"[+] Embedded message with k={args.k}")
    print(f"[+] Output video: {args.o}")


if __name__ == "__main__":
    main()
