# check_quality.py
#!/usr/bin/env python3

import cv2
import numpy as np
import sys


def compute_difference(original, modified):

    cap1 = cv2.VideoCapture(original)
    cap2 = cv2.VideoCapture(modified)

    ret1, frame1 = cap1.read()
    ret2, frame2 = cap2.read()

    if not ret1 or not ret2:
        print("[!] Cannot read frames")
        return

    gray1 = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
    gray2 = cv2.cvtColor(frame2, cv2.COLOR_BGR2GRAY)

    mse = np.mean((gray1.astype(float) - gray2.astype(float)) ** 2)

    print(f"\n=== Quality Analysis ===")
    print(f"{modified}")
    print(f"MSE : {mse:.2f}")

    if mse > 100:
        print("[!] Visible luminance distortion")
    else:
        print("[+] Minor visual distortion")

    cap1.release()
    cap2.release()


def main():

    if len(sys.argv) < 3:
        print("Usage: python3 check_quality.py original modified1 modified2")
        return

    original = sys.argv[1]

    for modified in sys.argv[2:]:
        compute_difference(original, modified)


if __name__ == "__main__":
    main()
