# vlc_analyzer.py
#!/usr/bin/env python3

import os
import sys


def analyze(original, modified):

    small_k = os.path.getsize(sys.argv[2])
    large_k = os.path.getsize(sys.argv[3])

    diff = large_k - small_k

    print("\n=== Relative VLC Expansion ===")

    print(f"k=2  Size : {small_k} bytes")
    print(f"k=45 Size : {large_k} bytes")

    print(f"Difference : {diff} bytes")

    if diff > 0:
        print("[!] Larger k increased VLC/Huffman size")
    else:
        print("[+] No significant VLC expansion")


def main():

    if len(sys.argv) != 4:
        print("Usage:")
        print("python3 vlc_analyzer.py input.mp4 output_k2.mp4 output_k45.mp4")
        return

    small_k = os.path.getsize(sys.argv[2])
    large_k = os.path.getsize(sys.argv[3])

    diff = large_k - small_k

    print("\n=== Relative VLC Expansion ===")

    print(f"k=2  Size : {small_k} bytes")
    print(f"k=45 Size : {large_k} bytes")

    print(f"Difference : {diff} bytes")

    if diff > 0:
        print("[!] Larger k increased VLC/Huffman size")
    elif diff < 0:
        print("[!] Re-encoding altered VLC distribution")
    else:
        print("[+] No measurable VLC difference")


if __name__ == "__main__":
    main()
