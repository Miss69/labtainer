# steg_dc_extract.py
#!/usr/bin/env python3

import cv2
import numpy as np
import argparse

END_MARKER = "###"


def bits_to_text(bits):

    chars = []

    for i in range(0, len(bits), 8):

        byte = bits[i:i+8]

        if len(byte) < 8:
            break

        chars.append(chr(int(byte, 2)))

    return ''.join(chars)


def extract(video):

    cap = cv2.VideoCapture(video)

    ret, frame = cap.read()

    if not ret:
        print("[!] Cannot read video")
        return

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    bits = []

    h, w = gray.shape

    for y in range(0, h - 7, 8):
        for x in range(0, w - 7, 8):

            block = gray[y:y+8, x:x+8]

            dct_block = cv2.dct(np.float32(block))

            dc = dct_block[0, 0]

            bit = '1' if dc > 1024 else '0'

            bits.append(bit)

    text = bits_to_text(''.join(bits))

    if END_MARKER in text:
        text = text.split(END_MARKER)[0]

    print("\n=== Extracted Message ===")
    print(text)

    cap.release()


def main():

    parser = argparse.ArgumentParser()

    parser.add_argument("video")

    args = parser.parse_args()

    extract(args.video)


if __name__ == "__main__":
    main()
