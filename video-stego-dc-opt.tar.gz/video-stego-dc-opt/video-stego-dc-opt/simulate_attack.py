# simulate_attack.py
#!/usr/bin/env python3

import cv2
import argparse


def recompress_video(input_file):

    if input_file.endswith(".mp4"):
        output_file = input_file.replace(".mp4", "_attacked.mp4")
    elif input_file.endswith(".avi"):
        output_file = input_file.replace(".avi", "_attacked.avi")
    else:
        output_file = input_file + "_attacked.mp4"

    cap = cv2.VideoCapture(input_file)

    fps = cap.get(cv2.CAP_PROP_FPS)

    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    fourcc = cv2.VideoWriter_fourcc(*'mp4v')

    out = cv2.VideoWriter(
        output_file,
        fourcc,
        fps,
        (width, height)
    )

    while True:

        ret, frame = cap.read()

        if not ret:
            break

        out.write(frame)

    cap.release()
    out.release()

    print(f"[+] Simulated compression attack: {output_file}")


def main():

    parser = argparse.ArgumentParser()

    parser.add_argument("videos", nargs='+')

    args = parser.parse_args()

    for video in args.videos:
        recompress_video(video)


if __name__ == "__main__":
    main()
